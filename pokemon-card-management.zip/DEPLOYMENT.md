# デプロイメントガイド

## GitHub経由での自動デプロイ設定

### 1. Google Apps Script プロジェクトの準備

#### 1.1 新しいスプレッドシートを作成
1. [Google Sheets](https://sheets.google.com) にアクセス
2. 「空白のスプレッドシート」を作成
3. スプレッドシート名を「ポケモンカード販売管理システム」に変更

#### 1.2 Apps Script プロジェクトを作成
1. スプレッドシートで「拡張機能」→「Apps Script」を選択
2. プロジェクト名を「PokemonCardManagement」に変更
3. 既存の `Code.gs` を削除
4. **重要**: プロジェクトのスクリプトIDをメモしておく（URLの `https://script.google.com/d/【スクリプトID】/edit` の部分）

### 2. Google Cloud Console での認証設定

#### 2.1 Google Cloud Console プロジェクトを作成
1. [Google Cloud Console](https://console.cloud.google.com) にアクセス
2. 新しいプロジェクトを作成（例：「pokemon-card-management」）
3. プロジェクトを選択

#### 2.2 Apps Script API を有効化
1. 「APIとサービス」→「ライブラリ」を選択
2. 「Google Apps Script API」を検索して有効化

#### 2.3 サービスアカウントを作成
1. 「APIとサービス」→「認証情報」を選択
2. 「認証情報を作成」→「サービスアカウント」を選択
3. サービスアカウント名を入力（例：「gas-deployer」）
4. 「作成して続行」をクリック
5. ロールは「編集者」を選択
6. 「完了」をクリック

#### 2.4 サービスアカウントキーを作成
1. 作成したサービスアカウントをクリック
2. 「キー」タブを選択
3. 「鍵を追加」→「新しい鍵を作成」を選択
4. キーのタイプは「JSON」を選択
5. 「作成」をクリック
6. ダウンロードされたJSONファイルを安全に保管

### 3. GitHub リポジトリの設定

#### 3.1 リポジトリの作成
```bash
# 既存のローカルリポジトリをGitHubにプッシュ
cd /Users/ryuji/Library/CloudStorage/GoogleDrive-sub3.mvc.bambi@gmail.com/マイドライブ/pokemon-card-management
git remote add origin https://github.com/【ユーザー名】/pokemon-card-management.git
git push -u origin main
```

#### 3.2 GitHub Secrets の設定
リポジトリの「Settings」→「Secrets and variables」→「Actions」で以下を設定：

1. **GAS_SCRIPT_ID**: Google Apps Script のスクリプトID
2. **GAS_CREDENTIALS**: サービスアカウントのJSONファイルの内容（全体をコピー）

### 4. デプロイの実行

#### 4.1 自動デプロイ
- `main` ブランチにプッシュすると自動的にデプロイが実行されます
- デプロイ状況は「Actions」タブで確認できます

#### 4.2 手動デプロイ
- リポジトリの「Actions」タブで「Deploy to Google Apps Script」ワークフローを手動実行

### 5. デプロイ後の確認

1. Google Apps Script エディタでコードが更新されていることを確認
2. スプレッドシートで「SalesOps」メニューが表示されることを確認
3. 「新規顧客作成」を実行してシートが正常に初期化されることを確認

## トラブルシューティング

### よくある問題

1. **認証エラー**
   - サービスアカウントのJSONファイルが正しく設定されているか確認
   - Apps Script API が有効化されているか確認

2. **スクリプトID エラー**
   - `.clasp.json` のスクリプトIDが正しいか確認
   - GitHub Secrets の `GAS_SCRIPT_ID` が正しく設定されているか確認

3. **デプロイ失敗**
   - GitHub Actions のログを確認
   - コードに構文エラーがないか確認

### サポート

問題が発生した場合は、GitHub Issues で報告してください。